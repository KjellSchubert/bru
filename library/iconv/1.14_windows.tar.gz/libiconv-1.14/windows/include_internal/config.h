/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to the number of bits in type 'ptrdiff_t'. */
#undef BITSIZEOF_PTRDIFF_T

/* Define to the number of bits in type 'sig_atomic_t'. */
#undef BITSIZEOF_SIG_ATOMIC_T

/* Define to the number of bits in type 'size_t'. */
#undef BITSIZEOF_SIZE_T

/* Define to the number of bits in type 'wchar_t'. */
#undef BITSIZEOF_WCHAR_T

/* Define to the number of bits in type 'wint_t'. */
#undef BITSIZEOF_WINT_T

/* Define to one of `_getb67', `GETB67', `getb67' for Cray-2 and Cray-YMP
   systems. This function is required for `alloca.c' support on those systems.
   */
#undef CRAY_STACKSEG_END

/* Define to 1 if using `alloca.c'. */
#undef C_ALLOCA

/* Define to 1 if // is a file system root distinct from /. */
#undef DOUBLE_SLASH_IS_DISTINCT_ROOT

/* Define as good substitute value for EILSEQ. */
//#undef EILSEQ // in errno.h on Windows

/* Define to 1 to enable a few rarely used encodings. */
#undef ENABLE_EXTRA

/* Define to 1 if translation of program messages to the user's native
   language is requested. */
#undef ENABLE_NLS

/* Define to 1 if the package shall run at any location in the file system. */
#undef ENABLE_RELOCATABLE

/* Define to 1 if realpath() can malloc memory, always gives an absolute path,
   and handles trailing slash correctly. */
#undef FUNC_REALPATH_WORKS

/* Define to a C preprocessor expression that evaluates to 1 or 0, depending
   whether the gnulib module canonicalize-lgpl shall be considered present. */
#undef GNULIB_CANONICALIZE_LGPL

/* Define to a C preprocessor expression that evaluates to 1 or 0, depending
   whether the gnulib module sigpipe shall be considered present. */
#undef GNULIB_SIGPIPE

/* Define to a C preprocessor expression that evaluates to 1 or 0, depending
   whether the gnulib module strerror shall be considered present. */
#undef GNULIB_STRERROR

/* Define to 1 when the gnulib module canonicalize_file_name should be tested.
   */
#undef GNULIB_TEST_CANONICALIZE_FILE_NAME

/* Define to 1 when the gnulib module environ should be tested. */
#undef GNULIB_TEST_ENVIRON

/* Define to 1 when the gnulib module lstat should be tested. */
#undef GNULIB_TEST_LSTAT

/* Define to 1 when the gnulib module read should be tested. */
#undef GNULIB_TEST_READ

/* Define to 1 when the gnulib module readlink should be tested. */
#undef GNULIB_TEST_READLINK

/* Define to 1 when the gnulib module realpath should be tested. */
#undef GNULIB_TEST_REALPATH

/* Define to 1 when the gnulib module sigprocmask should be tested. */
#undef GNULIB_TEST_SIGPROCMASK

/* Define to 1 when the gnulib module stat should be tested. */
#undef GNULIB_TEST_STAT

/* Define to 1 when the gnulib module strerror should be tested. */
#undef GNULIB_TEST_STRERROR

/* Define to 1 if you have `alloca', as a function or macro. */
#undef HAVE_ALLOCA

/* Define to 1 if you have <alloca.h> and it should be used (not on Ultrix).
   */
#undef HAVE_ALLOCA_H

/* Define to 1 if you have the `canonicalize_file_name' function. */
#undef HAVE_CANONICALIZE_FILE_NAME

/* Define to 1 if you have the MacOS X function CFLocaleCopyCurrent in the
   CoreFoundation framework. */
#undef HAVE_CFLOCALECOPYCURRENT

/* Define to 1 if you have the MacOS X function CFPreferencesCopyAppValue in
   the CoreFoundation framework. */
#undef HAVE_CFPREFERENCESCOPYAPPVALUE

/* Define if the GNU dcgettext() function is already present or preinstalled.
   */
#undef HAVE_DCGETTEXT

/* Define to 1 if you have the declaration of `clearerr_unlocked', and to 0 if
   you don't. */
#undef HAVE_DECL_CLEARERR_UNLOCKED

/* Define to 1 if you have the declaration of `feof_unlocked', and to 0 if you
   don't. */
#undef HAVE_DECL_FEOF_UNLOCKED

/* Define to 1 if you have the declaration of `ferror_unlocked', and to 0 if
   you don't. */
#undef HAVE_DECL_FERROR_UNLOCKED

/* Define to 1 if you have the declaration of `fflush_unlocked', and to 0 if
   you don't. */
#undef HAVE_DECL_FFLUSH_UNLOCKED

/* Define to 1 if you have the declaration of `fgets_unlocked', and to 0 if
   you don't. */
#undef HAVE_DECL_FGETS_UNLOCKED

/* Define to 1 if you have the declaration of `fputc_unlocked', and to 0 if
   you don't. */
#undef HAVE_DECL_FPUTC_UNLOCKED

/* Define to 1 if you have the declaration of `fputs_unlocked', and to 0 if
   you don't. */
#undef HAVE_DECL_FPUTS_UNLOCKED

/* Define to 1 if you have the declaration of `fread_unlocked', and to 0 if
   you don't. */
#undef HAVE_DECL_FREAD_UNLOCKED

/* Define to 1 if you have the declaration of `fwrite_unlocked', and to 0 if
   you don't. */
#undef HAVE_DECL_FWRITE_UNLOCKED

/* Define to 1 if you have the declaration of `getchar_unlocked', and to 0 if
   you don't. */
#undef HAVE_DECL_GETCHAR_UNLOCKED

/* Define to 1 if you have the declaration of `getc_unlocked', and to 0 if you
   don't. */
#undef HAVE_DECL_GETC_UNLOCKED

/* Define to 1 if you have the declaration of `program_invocation_name', and
   to 0 if you don't. */
#undef HAVE_DECL_PROGRAM_INVOCATION_NAME

/* Define to 1 if you have the declaration of `program_invocation_short_name',
   and to 0 if you don't. */
#undef HAVE_DECL_PROGRAM_INVOCATION_SHORT_NAME

/* Define to 1 if you have the declaration of `putchar_unlocked', and to 0 if
   you don't. */
#undef HAVE_DECL_PUTCHAR_UNLOCKED

/* Define to 1 if you have the declaration of `putc_unlocked', and to 0 if you
   don't. */
#undef HAVE_DECL_PUTC_UNLOCKED

/* Define to 1 if you have the declaration of `setenv', and to 0 if you don't.
   */
#undef HAVE_DECL_SETENV

/* Define to 1 if you have the declaration of `strerror_r', and to 0 if you
   don't. */
#undef HAVE_DECL_STRERROR_R

/* Define to 1 if you have the <dlfcn.h> header file. */
#undef HAVE_DLFCN_H

/* Define if you have the declaration of environ. */
#undef HAVE_ENVIRON_DECL

/* Define to 1 if you have the `getcwd' function. */
#undef HAVE_GETCWD

/* Define to 1 if you have the `getc_unlocked' function. */
#undef HAVE_GETC_UNLOCKED

/* Define if the GNU gettext() function is already present or preinstalled. */
#undef HAVE_GETTEXT

/* Define if you have the iconv() function and it works. */
#undef HAVE_ICONV

/* Define to 1 if you have the <inttypes.h> header file. */
#undef HAVE_INTTYPES_H

/* Define if you have <langinfo.h> and nl_langinfo(CODESET). */
#undef HAVE_LANGINFO_CODESET

/* Define to 1 if the system has the type `long long int'. */
#undef HAVE_LONG_LONG_INT

/* Define to 1 if you have the `lstat' function. */
#undef HAVE_LSTAT

/* Define to 1 if you have the <mach-o/dyld.h> header file. */
#undef HAVE_MACH_O_DYLD_H

/* Define to 1 if you have the `mbrtowc' function. */
#undef HAVE_MBRTOWC

/* Define to 1 if you have the `mbsinit' function. */
#undef HAVE_MBSINIT

/* Define to 1 if <wchar.h> declares mbstate_t. */
#undef HAVE_MBSTATE_T

/* Define to 1 if you have the `memmove' function. */
#undef HAVE_MEMMOVE

/* Define to 1 if you have the <memory.h> header file. */
#undef HAVE_MEMORY_H

/* Define to 1 if atoll is declared even after undefining macros. */
#undef HAVE_RAW_DECL_ATOLL

/* Define to 1 if canonicalize_file_name is declared even after undefining
   macros. */
#undef HAVE_RAW_DECL_CANONICALIZE_FILE_NAME

/* Define to 1 if chown is declared even after undefining macros. */
#undef HAVE_RAW_DECL_CHOWN

/* Define to 1 if dprintf is declared even after undefining macros. */
#undef HAVE_RAW_DECL_DPRINTF

/* Define to 1 if dup2 is declared even after undefining macros. */
#undef HAVE_RAW_DECL_DUP2

/* Define to 1 if dup3 is declared even after undefining macros. */
#undef HAVE_RAW_DECL_DUP3

/* Define to 1 if endusershell is declared even after undefining macros. */
#undef HAVE_RAW_DECL_ENDUSERSHELL

/* Define to 1 if environ is declared even after undefining macros. */
#undef HAVE_RAW_DECL_ENVIRON

/* Define to 1 if euidaccess is declared even after undefining macros. */
#undef HAVE_RAW_DECL_EUIDACCESS

/* Define to 1 if faccessat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FACCESSAT

/* Define to 1 if fchdir is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FCHDIR

/* Define to 1 if fchmodat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FCHMODAT

/* Define to 1 if fchownat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FCHOWNAT

/* Define to 1 if fcntl is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FCNTL

/* Define to 1 if ffsl is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FFSL

/* Define to 1 if ffsll is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FFSLL

/* Define to 1 if fpurge is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FPURGE

/* Define to 1 if fseeko is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FSEEKO

/* Define to 1 if fstatat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FSTATAT

/* Define to 1 if fsync is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FSYNC

/* Define to 1 if ftello is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FTELLO

/* Define to 1 if ftruncate is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FTRUNCATE

/* Define to 1 if futimens is declared even after undefining macros. */
#undef HAVE_RAW_DECL_FUTIMENS

/* Define to 1 if getcwd is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETCWD

/* Define to 1 if getdelim is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETDELIM

/* Define to 1 if getdomainname is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETDOMAINNAME

/* Define to 1 if getdtablesize is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETDTABLESIZE

/* Define to 1 if getgroups is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETGROUPS

/* Define to 1 if gethostname is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETHOSTNAME

/* Define to 1 if getline is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETLINE

/* Define to 1 if getloadavg is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETLOADAVG

/* Define to 1 if getlogin is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETLOGIN

/* Define to 1 if getlogin_r is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETLOGIN_R

/* Define to 1 if getpagesize is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETPAGESIZE

/* Define to 1 if getsubopt is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETSUBOPT

/* Define to 1 if getusershell is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GETUSERSHELL

/* Define to 1 if grantpt is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GRANTPT

/* Define to 1 if group_member is declared even after undefining macros. */
#undef HAVE_RAW_DECL_GROUP_MEMBER

/* Define to 1 if initstat_r is declared even after undefining macros. */
#undef HAVE_RAW_DECL_INITSTAT_R

/* Define to 1 if lchmod is declared even after undefining macros. */
#undef HAVE_RAW_DECL_LCHMOD

/* Define to 1 if lchown is declared even after undefining macros. */
#undef HAVE_RAW_DECL_LCHOWN

/* Define to 1 if link is declared even after undefining macros. */
#undef HAVE_RAW_DECL_LINK

/* Define to 1 if linkat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_LINKAT

/* Define to 1 if lseek is declared even after undefining macros. */
#undef HAVE_RAW_DECL_LSEEK

/* Define to 1 if lstat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_LSTAT

/* Define to 1 if memmem is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MEMMEM

/* Define to 1 if mempcpy is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MEMPCPY

/* Define to 1 if memrchr is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MEMRCHR

/* Define to 1 if mkdirat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MKDIRAT

/* Define to 1 if mkdtemp is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MKDTEMP

/* Define to 1 if mkfifo is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MKFIFO

/* Define to 1 if mkfifoat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MKFIFOAT

/* Define to 1 if mknod is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MKNOD

/* Define to 1 if mknodat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MKNODAT

/* Define to 1 if mkostemp is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MKOSTEMP

/* Define to 1 if mkostemps is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MKOSTEMPS

/* Define to 1 if mkstemp is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MKSTEMP

/* Define to 1 if mkstemps is declared even after undefining macros. */
#undef HAVE_RAW_DECL_MKSTEMPS

/* Define to 1 if openat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_OPENAT

/* Define to 1 if pipe is declared even after undefining macros. */
#undef HAVE_RAW_DECL_PIPE

/* Define to 1 if pipe2 is declared even after undefining macros. */
#undef HAVE_RAW_DECL_PIPE2

/* Define to 1 if popen is declared even after undefining macros. */
#undef HAVE_RAW_DECL_POPEN

/* Define to 1 if pread is declared even after undefining macros. */
#undef HAVE_RAW_DECL_PREAD

/* Define to 1 if pthread_sigmask is declared even after undefining macros. */
#undef HAVE_RAW_DECL_PTHREAD_SIGMASK

/* Define to 1 if ptsname is declared even after undefining macros. */
#undef HAVE_RAW_DECL_PTSNAME

/* Define to 1 if pwrite is declared even after undefining macros. */
#undef HAVE_RAW_DECL_PWRITE

/* Define to 1 if random_r is declared even after undefining macros. */
#undef HAVE_RAW_DECL_RANDOM_R

/* Define to 1 if rawmemchr is declared even after undefining macros. */
#undef HAVE_RAW_DECL_RAWMEMCHR

/* Define to 1 if readlink is declared even after undefining macros. */
#undef HAVE_RAW_DECL_READLINK

/* Define to 1 if readlinkat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_READLINKAT

/* Define to 1 if realpath is declared even after undefining macros. */
#undef HAVE_RAW_DECL_REALPATH

/* Define to 1 if renameat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_RENAMEAT

/* Define to 1 if rmdir is declared even after undefining macros. */
#undef HAVE_RAW_DECL_RMDIR

/* Define to 1 if rpmatch is declared even after undefining macros. */
#undef HAVE_RAW_DECL_RPMATCH

/* Define to 1 if setenv is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SETENV

/* Define to 1 if setstate_r is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SETSTATE_R

/* Define to 1 if setusershell is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SETUSERSHELL

/* Define to 1 if sigaction is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SIGACTION

/* Define to 1 if sigaddset is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SIGADDSET

/* Define to 1 if sigdelset is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SIGDELSET

/* Define to 1 if sigemptyset is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SIGEMPTYSET

/* Define to 1 if sigfillset is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SIGFILLSET

/* Define to 1 if sigismember is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SIGISMEMBER

/* Define to 1 if sigpending is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SIGPENDING

/* Define to 1 if sigprocmask is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SIGPROCMASK

/* Define to 1 if sleep is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SLEEP

/* Define to 1 if snprintf is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SNPRINTF

/* Define to 1 if srandom_r is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SRANDOM_R

/* Define to 1 if stat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STAT

/* Define to 1 if stpcpy is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STPCPY

/* Define to 1 if stpncpy is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STPNCPY

/* Define to 1 if strcasestr is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRCASESTR

/* Define to 1 if strchrnul is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRCHRNUL

/* Define to 1 if strdup is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRDUP

/* Define to 1 if strerror_r is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRERROR_R

/* Define to 1 if strncat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRNCAT

/* Define to 1 if strndup is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRNDUP

/* Define to 1 if strnlen is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRNLEN

/* Define to 1 if strpbrk is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRPBRK

/* Define to 1 if strsep is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRSEP

/* Define to 1 if strsignal is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRSIGNAL

/* Define to 1 if strtod is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRTOD

/* Define to 1 if strtok_r is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRTOK_R

/* Define to 1 if strtoll is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRTOLL

/* Define to 1 if strtoull is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRTOULL

/* Define to 1 if strverscmp is declared even after undefining macros. */
#undef HAVE_RAW_DECL_STRVERSCMP

/* Define to 1 if symlink is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SYMLINK

/* Define to 1 if symlinkat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_SYMLINKAT

/* Define to 1 if tmpfile is declared even after undefining macros. */
#undef HAVE_RAW_DECL_TMPFILE

/* Define to 1 if ttyname_r is declared even after undefining macros. */
#undef HAVE_RAW_DECL_TTYNAME_R

/* Define to 1 if unlink is declared even after undefining macros. */
#undef HAVE_RAW_DECL_UNLINK

/* Define to 1 if unlinkat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_UNLINKAT

/* Define to 1 if unlockpt is declared even after undefining macros. */
#undef HAVE_RAW_DECL_UNLOCKPT

/* Define to 1 if unsetenv is declared even after undefining macros. */
#undef HAVE_RAW_DECL_UNSETENV

/* Define to 1 if usleep is declared even after undefining macros. */
#undef HAVE_RAW_DECL_USLEEP

/* Define to 1 if utimensat is declared even after undefining macros. */
#undef HAVE_RAW_DECL_UTIMENSAT

/* Define to 1 if vdprintf is declared even after undefining macros. */
#undef HAVE_RAW_DECL_VDPRINTF

/* Define to 1 if vsnprintf is declared even after undefining macros. */
#undef HAVE_RAW_DECL_VSNPRINTF

/* Define to 1 if _Exit is declared even after undefining macros. */
#undef HAVE_RAW_DECL__EXIT

/* Define to 1 if you have the `readlink' function. */
#undef HAVE_READLINK

/* Define to 1 if you have the `readlinkat' function. */
#undef HAVE_READLINKAT

/* Define to 1 if you have the `realpath' function. */
#undef HAVE_REALPATH

/* Define to 1 if you have the <search.h> header file. */
#undef HAVE_SEARCH_H

/* Define to 1 if you have the `setenv' function. */
#undef HAVE_SETENV

/* Define to 1 if you have the `setlocale' function. */
#undef HAVE_SETLOCALE

/* Define to 1 if 'sig_atomic_t' is a signed integer type. */
#undef HAVE_SIGNED_SIG_ATOMIC_T

/* Define to 1 if 'wchar_t' is a signed integer type. */
#undef HAVE_SIGNED_WCHAR_T

/* Define to 1 if 'wint_t' is a signed integer type. */
#undef HAVE_SIGNED_WINT_T

/* Define to 1 if the system has the type `sigset_t'. */
#undef HAVE_SIGSET_T

/* Define to 1 if you have the <stdint.h> header file. */
#undef HAVE_STDINT_H

/* Define to 1 if you have the <stdlib.h> header file. */
#undef HAVE_STDLIB_H

/* Define to 1 if you have the `strerror_r' function. */
#undef HAVE_STRERROR_R

/* Define to 1 if you have the <strings.h> header file. */
#undef HAVE_STRINGS_H

/* Define to 1 if you have the <string.h> header file. */
#undef HAVE_STRING_H

/* Define to 1 if you have the <sys/bitypes.h> header file. */
#undef HAVE_SYS_BITYPES_H

/* Define to 1 if you have the <sys/inttypes.h> header file. */
#undef HAVE_SYS_INTTYPES_H

/* Define to 1 if you have the <sys/param.h> header file. */
#undef HAVE_SYS_PARAM_H

/* Define to 1 if you have the <sys/socket.h> header file. */
#undef HAVE_SYS_SOCKET_H

/* Define to 1 if you have the <sys/stat.h> header file. */
#undef HAVE_SYS_STAT_H

/* Define to 1 if you have the <sys/time.h> header file. */
#undef HAVE_SYS_TIME_H

/* Define to 1 if you have the <sys/types.h> header file. */
#undef HAVE_SYS_TYPES_H

/* Define to 1 if you have the `tsearch' function. */
#undef HAVE_TSEARCH

/* Define to 1 if you have the <unistd.h> header file. */
#undef HAVE_UNISTD_H

/* Define to 1 if the system has the type `unsigned long long int'. */
#undef HAVE_UNSIGNED_LONG_LONG_INT

/* Define to 1 or 0, depending whether the compiler supports simple visibility
   declarations. */
#undef HAVE_VISIBILITY

/* Define to 1 if you have the <wchar.h> header file. */
#undef HAVE_WCHAR_H

/* Define if you have the 'wchar_t' type. */
#undef HAVE_WCHAR_T

/* Define to 1 if you have the `wcrtomb' function. */
#undef HAVE_WCRTOMB

/* Define to 1 if you have the <winsock2.h> header file. */
#undef HAVE_WINSOCK2_H

/* Define to 1 if O_NOATIME works. */
#undef HAVE_WORKING_O_NOATIME

/* Define to 1 if O_NOFOLLOW works. */
#undef HAVE_WORKING_O_NOFOLLOW

/* Define to 1 if the system has the type `_Bool'. */
#undef HAVE__BOOL

/* Define to 1 if you have the `_NSGetExecutablePath' function. */
#undef HAVE__NSGETEXECUTABLEPATH

/* Define as const if the declaration of iconv() needs const. */
#define ICONV_CONST

/* Define to the value of ${prefix}, as a string. */
#undef INSTALLPREFIX

/* Define to 1 if `lstat' dereferences a symlink specified with a trailing
   slash. */
#undef LSTAT_FOLLOWS_SLASHED_SYMLINK

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
#undef LT_OBJDIR

/* If malloc(0) is != NULL, define this to 1. Otherwise define this to 0. */
#undef MALLOC_0_IS_NONNULL

/* Define to 1 if your C compiler doesn't accept -c and -o together. */
#undef NO_MINUS_C_MINUS_O

/* Name of package */
#undef PACKAGE

/* Define to the address where bug reports for this package should be sent. */
#undef PACKAGE_BUGREPORT

/* Define to the full name of this package. */
#undef PACKAGE_NAME

/* Define to the full name and version of this package. */
#undef PACKAGE_STRING

/* Define to the one symbol short name of this package. */
#undef PACKAGE_TARNAME

/* Define to the home page for this package. */
#undef PACKAGE_URL

/* Define to the version of this package. */
#undef PACKAGE_VERSION

/* Define to l, ll, u, ul, ull, etc., as suitable for constants of type
   'ptrdiff_t'. */
#undef PTRDIFF_T_SUFFIX

/* Define to 1 if readlink fails to recognize a trailing slash. */
#undef READLINK_TRAILING_SLASH_BUG

/* Define to 1 if stat needs help when passed a directory name with a trailing
   slash */
#undef REPLACE_FUNC_STAT_DIR

/* Define to 1 if stat needs help when passed a file name with a trailing
   slash */
#undef REPLACE_FUNC_STAT_FILE

/* Define to 1 if strerror(0) does not return a message implying success. */
#undef REPLACE_STRERROR_0

/* Define to l, ll, u, ul, ull, etc., as suitable for constants of type
   'sig_atomic_t'. */
#undef SIG_ATOMIC_T_SUFFIX

/* Define to l, ll, u, ul, ull, etc., as suitable for constants of type
   'size_t'. */
#undef SIZE_T_SUFFIX

/* If using the C implementation of alloca, define if you know the
   direction of stack growth for your system; otherwise it will be
   automatically deduced at runtime.
	STACK_DIRECTION > 0 => grows toward higher addresses
	STACK_DIRECTION < 0 => grows toward lower addresses
	STACK_DIRECTION = 0 => direction of growth unknown */
#undef STACK_DIRECTION

/* Define to 1 if the `S_IS*' macros in <sys/stat.h> do not work properly. */
#undef STAT_MACROS_BROKEN

/* Define to 1 if you have the ANSI C header files. */
#undef STDC_HEADERS

/* Define to 1 if strerror_r returns char *. */
#undef STRERROR_R_CHAR_P

/* Define to the prefix of C symbols at the assembler and linker level, either
   an underscore or empty. */
#undef USER_LABEL_PREFIX

/* Define to 1 if you want getc etc. to use unlocked I/O if available.
   Unlocked I/O can improve performance in unithreaded apps, but it is not
   safe for multithreaded apps. */
#undef USE_UNLOCKED_IO

/* Version number of package */
#undef VERSION

/* Define to l, ll, u, ul, ull, etc., as suitable for constants of type
   'wchar_t'. */
#undef WCHAR_T_SUFFIX

/* Define to l, ll, u, ul, ull, etc., as suitable for constants of type
   'wint_t'. */
#undef WINT_T_SUFFIX

/* Define if the machine's byte ordering is little endian. */
#undef WORDS_LITTLEENDIAN

/* Define to 1 if on MINIX. */
#undef _MINIX

/* The _Noreturn keyword of draft C1X.  */
#ifndef _Noreturn
# if (3 <= __GNUC__ || (__GNUC__ == 2 && 8 <= __GNUC_MINOR__) \
      || 0x5110 <= __SUNPRO_C)
#  define _Noreturn __attribute__ ((__noreturn__))
# elif 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn
# endif
#endif


/* Define to 2 if the system does not provide POSIX.1 features except with
   this defined. */
#undef _POSIX_1_SOURCE

/* Define to 1 if you need to in order for `stat' and other things to work. */
#undef _POSIX_SOURCE

/* Define to 500 only on HP-UX. */
#undef _XOPEN_SOURCE

/* Enable extensions on AIX 3, Interix.  */
#ifndef _ALL_SOURCE
# undef _ALL_SOURCE
#endif
/* Enable general extensions on MacOS X.  */
#ifndef _DARWIN_C_SOURCE
# undef _DARWIN_C_SOURCE
#endif
/* Enable GNU extensions on systems that have them.  */
#ifndef _GNU_SOURCE
# undef _GNU_SOURCE
#endif
/* Enable threading extensions on Solaris.  */
#ifndef _POSIX_PTHREAD_SEMANTICS
# undef _POSIX_PTHREAD_SEMANTICS
#endif
/* Enable extensions on HP NonStop.  */
#ifndef _TANDEM_SOURCE
# undef _TANDEM_SOURCE
#endif
/* Enable general extensions on Solaris.  */
#ifndef __EXTENSIONS__
# undef __EXTENSIONS__
#endif


/* Define to `int' if <sys/types.h> doesn't define. */
#undef gid_t

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
#undef inline
#endif

/* Work around a bug in Apple GCC 4.0.1 build 5465: In C99 mode, it supports
   the ISO C 99 semantics of 'extern inline' (unlike the GNU C semantics of
   earlier versions), but does not display it by setting __GNUC_STDC_INLINE__.
   __APPLE__ && __MACH__ test for MacOS X.
   __APPLE_CC__ tests for the Apple compiler and its version.
   __STDC_VERSION__ tests for the C99 mode.  */
#if defined __APPLE__ && defined __MACH__ && __APPLE_CC__ >= 5465 && !defined __cplusplus && __STDC_VERSION__ >= 199901L && !defined __GNUC_STDC_INLINE__
# define __GNUC_STDC_INLINE__ 1
#endif

/* Define to a type if <wchar.h> does not define. */
#undef mbstate_t

/* Define to the type of st_nlink in struct stat, or a supertype. */
#undef nlink_t

/* Define to the equivalent of the C99 'restrict' keyword, or to
   nothing if this is not supported.  Do not define if restrict is
   supported directly.  */
#undef restrict
/* Work around a bug in Sun C++: it does not support _Restrict or
   __restrict__, even though the corresponding Sun C compiler ends up with
   "#define restrict _Restrict" or "#define restrict __restrict__" in the
   previous line.  Perhaps some future version of Sun C++ will work with
   restrict; if so, hopefully it defines __RESTRICT like Sun C does.  */
#if defined __SUNPRO_CC && !defined __RESTRICT
# define _Restrict
# define __restrict__
#endif

/* Define to `unsigned int' if <sys/types.h> does not define. */
#undef size_t

/* Define as a signed type of the same size as size_t. */
#undef ssize_t

/* Define to `int' if <sys/types.h> doesn't define. */
#undef uid_t

/* Define as a marker that can be attached to declarations that might not
    be used.  This helps to reduce warnings, such as from
    GCC -Wunused-parameter.  */
#if __GNUC__ >= 3 || (__GNUC__ == 2 && __GNUC_MINOR__ >= 7)
# define _GL_UNUSED __attribute__ ((__unused__))
#else
# define _GL_UNUSED
#endif
/* The name _UNUSED_PARAMETER_ is an earlier spelling, although the name
   is a misnomer outside of parameter lists.  */
#define _UNUSED_PARAMETER_ _GL_UNUSED

/* The __pure__ attribute was added in gcc 2.96.  */
#if __GNUC__ > 2 || (__GNUC__ == 2 && __GNUC_MINOR__ >= 96)
# define _GL_ATTRIBUTE_PURE __attribute__ ((__pure__))
#else
# define _GL_ATTRIBUTE_PURE /* empty */
#endif

/* The __const__ attribute was added in gcc 2.95.  */
#if __GNUC__ > 2 || (__GNUC__ == 2 && __GNUC_MINOR__ >= 95)
# define _GL_ATTRIBUTE_CONST __attribute__ ((__const__))
#else
# define _GL_ATTRIBUTE_CONST /* empty */
#endif



/* On Windows, variables that may be in a DLL must be marked specially.  */
#if defined _MSC_VER && defined _DLL
# define DLL_VARIABLE __declspec (dllimport)
#else
# define DLL_VARIABLE
#endif
